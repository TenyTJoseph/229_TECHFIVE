
<h1 class="text-center display-3 pt-2">Search</h1>
<?php echo validation_errors('<p class="alert alert-dismissable alert-danger">'); ?>
<?= form_open('admin/search/result',['id'=>'form_search']) ?>
<div class="row mt-4">
	<div  class="col-sm-12">
		<div class="form-group">
			<input type="text" id="search_bar" name="search_bar" class="form-control search_bar" placeholder="Searh by Name / Batch / UID / stream" >
		</div>
	</div>
	<input class="btn btn-primary ml-3" type="submit" value="Search" id="search_btn">

<div class="container">
	
	<div class="row" id="filter">
		<form>
			<div class="form-group col-sm-3 col-xs-6">
				<select data-filter="make" class="filter-make filter form-control">
					<option value="">Select Name</option>
					<option value="">Show All</option>
				</select>
			</div>
			<div class="form-group col-sm-3 col-xs-6">
				<select data-filter="model" class="filter-model filter form-control">
					<option value="">Select Batch</option>
					<option value="">Show All</option>
				</select>
			</div>
			<div class="form-group col-sm-3 col-xs-6">
				<select data-filter="type" class="filter-type filter form-control">
					<option value="">Select UID</option>
					<option value="">Show All</option>
				</select>
			</div>
			<div class="form-group col-sm-3 col-xs-6">
				<select data-filter="price" class="filter-price filter form-control">
					<option value="">Select Stream</option>
					<option value="">Show All</option>
				</select>
			</div>
		</form>
	</div>
	<div class="row" id="products">
		
	</div>
</div>
</div>
<?= form_close()?>
