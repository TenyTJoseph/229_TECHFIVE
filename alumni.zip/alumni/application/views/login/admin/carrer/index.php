<a href="<?= base_url('admin/carrer/add')?>" class="btn btn-primary mt-4 ml-2">Add Carrer Opportunities</a>
<hr>
<h1 class="display-4">Recently Uploaded Carrer Opportunities</h1>
<div class="table-responsive">
	<table class="table table-striped">
		<thead>
			<th>Id</th>
			<th>Title</th>
			<th>Description</th>
			<th>Location</th>
			<th>Duration</th>
			<th>Stipend</th>
			<th>Work Type</th>
			<th>Link</th>
			<th>year</th>
			<th>action</th>
		</thead>
		<tbody>
		</tbody>
	</table>
</div>