</div>
<footer style="background-color:white; padding:100px;" class="footer">
    <div class="container" style="text-align: center">
        <span class="text-muted">© 2020 <a href="http://centraluniversity.com/" class="href">Central University Punjab, Bathinda</a>. All Rights Reserved</span>
    </div>
</footer>
</body>
</html>