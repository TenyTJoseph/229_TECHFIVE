<?php 

class Carrer_model extends CI_Model{

}