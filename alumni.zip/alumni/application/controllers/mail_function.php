<?php	
	function sendOTP($email,$otp) {
		require('phpmailer/class.phpmailer.php');
	
		$message_body = "One Time Password for PHP login authentication is:<br/><br/>" . $otp;
		$mail = new PHPMailer();
		$mail->AddReplyTo("chrisachu2000@gmail.com","techfive");
		
		
		$mail->SetFrom("chrisachu2000@gmail.com", "techfive");
		$mail->AddAddress($email);
		$mail->Subject = "OTP to Login";
		$mail->MsgHTML($message_body);
				
		$result = $mail->Send();
		
			
		return $result;
	}
?>